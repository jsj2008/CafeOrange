
// MFCResourceGarageView.cpp : implementation of the CMFCResourceGarageView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "MFCResourceGarage.h"
#endif

#include "MFCResourceGarageDoc.h"
#include "MFCResourceGarageView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMFCResourceGarageView

IMPLEMENT_DYNCREATE(CMFCResourceGarageView, CView)

BEGIN_MESSAGE_MAP(CMFCResourceGarageView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMFCResourceGarageView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CMFCResourceGarageView construction/destruction

CMFCResourceGarageView::CMFCResourceGarageView()
{
	// TODO: add construction code here

}

CMFCResourceGarageView::~CMFCResourceGarageView()
{
}

BOOL CMFCResourceGarageView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CMFCResourceGarageView drawing

void CMFCResourceGarageView::OnDraw(CDC* /*pDC*/)
{
	CMFCResourceGarageDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
}


// CMFCResourceGarageView printing


void CMFCResourceGarageView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMFCResourceGarageView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMFCResourceGarageView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMFCResourceGarageView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CMFCResourceGarageView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMFCResourceGarageView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMFCResourceGarageView diagnostics

#ifdef _DEBUG
void CMFCResourceGarageView::AssertValid() const
{
	CView::AssertValid();
}

void CMFCResourceGarageView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFCResourceGarageDoc* CMFCResourceGarageView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFCResourceGarageDoc)));
	return (CMFCResourceGarageDoc*)m_pDocument;
}
#endif //_DEBUG


// CMFCResourceGarageView message handlers
