﻿using System;
using System.Collections.Generic;


public enum eLineShapeType
{
    SHAPE_TYPE_SINGLE,
    SHAPE_TYPE_MULTI,
};

public enum eAxisAlign
{
    AXIS_ALIGN_X,
    AXIS_ALIGN_Y,
    AXIS_ALIGN_Z,
};

public enum eCurveShapeType
{
    SHAPE_TYPE_FREE,
    SHAPE_TYPE_BEZIER,
    SHAPE_TYPE_BSPLINE,
    SHAPE_TYPE_PARABOLIC,
    SHAPE_TYPE_SIN,
    SHAPE_TYPE_TAN,
};



