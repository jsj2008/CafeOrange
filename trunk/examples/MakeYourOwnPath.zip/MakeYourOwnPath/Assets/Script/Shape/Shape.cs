﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Shape : MonoBehaviour
{
    [System.Serializable]
    public class ControlPoint
    {
        public Vector3 position = new Vector3();
        public Vector3 rotation = new Vector3();

        public ControlPoint()
        {
            position = rotation = Vector3.zero;
        }
        public ControlPoint(Vector3 pos)
        {
            position = pos;
            rotation = Vector3.zero;
        }
        public ControlPoint(Vector3 pos, Vector3 rot)
        {
            position = pos;
            rotation = rot;
        }
    };

    [System.Serializable]
    public class CurveControlPoints
    {
        public int SectionSize;
        public List<ControlPoint> ControlPointList = new List<ControlPoint>();

        private float PointStep = 3.0f;

        public CurveControlPoints()
        {
        }
        public void MakeSection(int SectionSize, eAxisAlign align)
        {
            ControlPointList.Clear();
            this.SectionSize = SectionSize;
            for (int index = 0; index < SectionSize; index++)
            {
                MakeControlPoint(index, align);
            }
            AdjustControlPointTransform();
        }
        void MakeControlPoint(int Section, eAxisAlign align)
        {
            float SectionInterval = Section * PointStep * 3;
            switch (align)
            {
                case eAxisAlign.AXIS_ALIGN_X:
                    if (Section == 0)
                        ControlPointList.Add(new ControlPoint(new Vector3(SectionInterval, 0, 0)));
                    ControlPointList.Add(new ControlPoint(new Vector3(PointStep + SectionInterval, PointStep, 0)));
                    ControlPointList.Add(new ControlPoint(new Vector3(PointStep * 2 + SectionInterval, PointStep, 0)));
                    ControlPointList.Add(new ControlPoint(new Vector3(PointStep * 3 + SectionInterval, 0, 0)));
                    break;
                case eAxisAlign.AXIS_ALIGN_Y:
                    if (Section == 0)
                        ControlPointList.Add(new ControlPoint(new Vector3(0, SectionInterval, 0)));
                    ControlPointList.Add(new ControlPoint(new Vector3(PointStep, PointStep + SectionInterval, 0)));
                    ControlPointList.Add(new ControlPoint(new Vector3(PointStep, PointStep * 2 + SectionInterval, 0)));
                    ControlPointList.Add(new ControlPoint(new Vector3(0, PointStep * 3 + SectionInterval, 0)));
                    break;
                case eAxisAlign.AXIS_ALIGN_Z:
                    if (Section == 0)
                        ControlPointList.Add(new ControlPoint(new Vector3(0, 0, SectionInterval)));
                    ControlPointList.Add(new ControlPoint(new Vector3(0, PointStep, PointStep + SectionInterval)));
                    ControlPointList.Add(new ControlPoint(new Vector3(0, PointStep, PointStep * 2 + SectionInterval)));
                    ControlPointList.Add(new ControlPoint(new Vector3(0, 0, PointStep * 3 + SectionInterval)));
                    break;
            }
        }
        public void AdjustControlPointTransform()
        {
            Vector3 origin = ControlPointList[0].position;
            for (int index = 0; index < ControlPointList.Count; index++)
            {
                Vector3 position = ControlPointList[index].position - origin;
                ControlPointList[index].position = position;
            }
        }
    };

    protected Vector3 BasePosition = new Vector3();
    protected Vector3 NewBasePosition = new Vector3();
    

#region (Editor Property)
    public eAxisAlign AxisAlign;
    public bool FixedTransform = false;
    public bool AutoDirection = true;
#endregion

    void Awake()
    {
        BasePosition = transform.position;
    }

 
}

