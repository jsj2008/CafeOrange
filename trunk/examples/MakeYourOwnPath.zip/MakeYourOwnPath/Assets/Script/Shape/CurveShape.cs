﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CurveShape :  Shape
{
 #region (Editor Property)
    public int SectionSize = 2;
    public int Resolution =  20;
 #endregion

    protected eCurveShapeType ShapeType;    
    public CurveControlPoints curveControlPoints = new CurveControlPoints();
    protected List<ControlPoint> CurvePointList = new List<ControlPoint>();

    protected void   CreateCurveGuide(int SectionSize)
    {
        curveControlPoints.MakeSection(SectionSize,AxisAlign);        
    }
    protected void   CreateCurve()
    {
        CurvePointList.Clear();

        for (int section = 0; section < SectionSize; section++)
        {
            Vector3 c0 = GetControlPoint(section, 0);
            Vector3 c1 = GetControlPoint(section, 1);
            Vector3 c2 = GetControlPoint(section, 2);
            Vector3 c3 = GetControlPoint(section, 3);

            for (int i = 0; i < Resolution; i++)
            {
                float t = (float)i / (float)Resolution;

                ControlPoint point = new ControlPoint();
                point.position.x = (BersteinCurve_B0(t) * c0.x) + (BersteinCurve_B1(t) * c1.x) +
                                                (BersteinCurve_B2(t) * c2.x) + (BersteinCurve_B3(t) * c3.x);

                point.position.y = (BersteinCurve_B0(t) * c0.y) + (BersteinCurve_B1(t) * c1.y) +
                                                (BersteinCurve_B2(t) * c2.y) + (BersteinCurve_B3(t) * c3.y);

                point.position.z = (BersteinCurve_B0(t) * c0.z) + (BersteinCurve_B1(t) * c1.z) +
                                                (BersteinCurve_B2(t) * c2.z) + (BersteinCurve_B3(t) * c3.z);

                CurvePointList.Add(point);
            }
        }
    }
    public Vector3 GetControlPoint(int index)
    {
        return curveControlPoints.ControlPointList[index].position;    
    }
    public Vector3 GetControlPoint(int section, int index)
    {
        int controlPointIndex = 0;
        if (section == 0)
            controlPointIndex = index;
        else
            controlPointIndex = 4 * section + index - section; 

        return GetControlPoint(controlPointIndex);
    }
    public void       SetPoint(int index, Vector3 position)
    {
        curveControlPoints.ControlPointList[index].position = position;
        CreateCurve();
    }
    public Vector3 GetPoint(float t)
    {
        return GetInterpolatedPoint(t);
    }
    protected virtual Vector3 GetInterpolatedPoint(float t)
    {
        return Vector3.zero;
    }
    
    protected void MoveControlPoints(Vector3 Movement)
    {
        foreach (ControlPoint controlPoint in curveControlPoints.ControlPointList)
        {
            controlPoint.position += Movement;
        }
        curveControlPoints.AdjustControlPointTransform();
    }      

    public List<ControlPoint> GetCurvePoint()
    {
        return CurvePointList;
    }

#region (Berstein Curve Algorithm)
    public float BersteinCurve_B0(float t)
    {
        return ((1f - t) * (1f - t) * (1f - t));
    }
    public float BersteinCurve_B1(float t)
    {
        return (3f * t * (1 - t) * (1f - t));
    }
    public float BersteinCurve_B2(float t)
    {
        return (3f * t * t * (1 - t));
    }
    public float BersteinCurve_B3(float t)
    {
        return (t * t * t);
    }
    public float BersteinCurve_D0(float t)
    {
        return (6f * t) - (3f * t * t) - 3f;
    }
    public float BersteinCurve_D1(float t)
    {
        return 3f - (12f * t) + (9f * t * t);
    }
    public float BersteinCurve_D2(float t)
    {
        return (6f * t) - (9f * t * t);
    }
    public float BersteinCurve_D3(float t)
    {
        return (3f * t * t);
    }
#endregion

}
