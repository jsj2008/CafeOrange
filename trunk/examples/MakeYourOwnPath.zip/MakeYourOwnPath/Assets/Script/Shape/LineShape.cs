﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LineShape : Shape 
{
    protected eLineShapeType ShapeType;
    public List<ControlPoint> ControlPointList = new List<ControlPoint>();

    public LineShape()
    {
        AxisAlign = eAxisAlign.AXIS_ALIGN_X;       
    }

    public void SetPoint(int index, Vector3 position)
    {
        SetControlPoint(index,position);
    }

    public Vector3 GetPoint(float t)
    {
        return GetInterpolatedPoint(t);
    }

     public void AddControlPoint(Vector3 position)
     {         
         ControlPointList.Add(new ControlPoint(position));
     }

     protected  virtual Vector3 GetInterpolatedPoint(float t)
     {
         return Vector3.zero;
     }

     public Vector3 GetControlPoint(int index)
     {
         return ControlPointList[index].position;
     }

     public void SetControlPoint(int index, Vector3 position)
     {
         ControlPointList[index].position = position;
     }

     public void MoveControlPoints(Vector3 Movement)
     {
         foreach (ControlPoint controlPoint in ControlPointList)
         {
             controlPoint.position += Movement;
         }
     }

     public void AdjustControlPointTransform()
     {
         Vector3 origin = ControlPointList[0].position;
         for (int index = 0; index < ControlPointList.Count; index++)
         {
             Vector3 position = ControlPointList[index].position - origin;
             ControlPointList[index].position = position;
         }
     }

     void OnDrawGizmosSelected()
     {
         if (FixedTransform)
         {
             transform.position = Vector3.zero;
             return;
         }
         NewBasePosition = transform.position;

         if (NewBasePosition != BasePosition)
         {
             Vector3 Movement = NewBasePosition - BasePosition;
             MoveControlPoints(Movement);
             BasePosition = NewBasePosition;

             AdjustControlPointTransform();
         }
     }
       
}