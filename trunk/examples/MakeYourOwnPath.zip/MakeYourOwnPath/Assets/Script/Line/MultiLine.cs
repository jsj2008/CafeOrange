﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode]
public class MultiLine :  LineShape
{
    [System.Serializable]
    public class SectionInfo
    {
        public float  Duration;
     
        public SectionInfo()
        {
            Duration = 5.0f;     
        }
    };

    [HideInInspector]
    public int ControlPointSize = 3;
    
    public List<SectionInfo> SectionInfoList = new List<SectionInfo>();

    private float StepSize = 2.0f;
    private int CurrentSection = 0;

    private Vector3 Direction = new Vector3();
    private Vector3 Angle      = new Vector3();


    public MultiLine()
    {
        ShapeType = eLineShapeType.SHAPE_TYPE_MULTI;

        Reset();
    }

    public void Reset()
    {
        CurrentSection = 0;

        MakeMultiControlPoint();
        MakeSectionInfo();
        MakeForwardDirection();
    }

    void MakeMultiControlPoint()
    {
        if (ControlPointList.Count == 0)
        {
            for (int index = 0; index < ControlPointSize; index++)
            {
                switch (AxisAlign)
                {
                    case eAxisAlign.AXIS_ALIGN_X : AddControlPoint(new Vector3(index * StepSize, 0f, 0f)); break;
                    case eAxisAlign.AXIS_ALIGN_Y:  AddControlPoint(new Vector3(0f, index * StepSize,  0f)); break;
                    case eAxisAlign.AXIS_ALIGN_Z:  AddControlPoint(new Vector3(0f, index * StepSize,  0f)); break;
                }
            }
        }
        else if(ControlPointSize < ControlPointList.Count)
        {
            ControlPointList.RemoveRange(ControlPointSize, ControlPointList.Count - ControlPointSize);
        }
        else if (ControlPointSize > ControlPointList.Count)
        {
            Vector3 p0 = GetControlPoint(ControlPointList.Count - 2);
            Vector3 p1 = GetControlPoint(ControlPointList.Count - 1);

            Vector3 direction = Vector3.Normalize(p1 - p0);
            for (int index = 0; index <=ControlPointSize - ControlPointList.Count  ; index++ )
            {
                AddControlPoint(p1 + direction * (index+1)* 5.0f);
            }
        }
    }

    void MakeSectionInfo()
    {
        if (SectionInfoList.Count > 0)
            SectionInfoList.Clear();

        for (int index = 0; index < ControlPointSize; index++)
        {
            SectionInfoList.Add(new SectionInfo());
        }
    }

    void MakeForwardDirection()
    {
        Vector3 p0 = GetControlPoint(CurrentSection);
        Vector3 p1 = GetControlPoint(CurrentSection + 1);

        Vector3 ForwardDirection = p1 - p0; 

        Angle.x = Vector3.Angle(ForwardDirection, new Vector3(1, 0, 0));
        Angle.y = Vector3.Angle(ForwardDirection, new Vector3(0, 1, 0));
        Angle.z = 0; // Vector3.Angle(ForwardDirection, new Vector3(0, 0, -1));

        Direction = ForwardDirection;
        Direction.Normalize();
    }

    public void ProceedSection()
    {
        CurrentSection++;

        if (CurrentSection == SectionInfoList.Count - 1){
            CurrentSection = 0;
        }

        MakeForwardDirection();

     //Debug.Log("ForwardDirection : " + Direction);
     // Debug.Log("ForwardAngle(x,y,z) : " + Angle);
    }

    public float GetDuration()
    {
        return SectionInfoList[CurrentSection].Duration;
    }

    public Vector3 GetDirection()
    {
        return Direction;
    }

    public Vector3 GetAngle()
    {
        return Angle;
    }

    protected override Vector3 GetInterpolatedPoint(float t)
    {
        Vector3 p0 = GetControlPoint(CurrentSection);
        Vector3 p1 = GetControlPoint(CurrentSection + 1);

        float xpos = p0.x * (1 - t) + p1.x * t;
        float ypos = p0.y * (1 - t) + p1.y * t;
        float zpos = p0.z * (1 - t) + p1.z * t;

        return new Vector3(xpos, ypos, zpos);
    }

  
}

