﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode]
public class SingleLine :  LineShape
{
    public SingleLine()
    {
        ShapeType = eLineShapeType.SHAPE_TYPE_SINGLE;
        AddControlPoint(new Vector3(BasePosition.x * 1.5f, BasePosition.y, BasePosition.z));
        AddControlPoint(new Vector3(BasePosition.x * -1.5f, BasePosition.y, BasePosition.z));

        AdjustControlPointTransform();   
    }

    protected override Vector3  GetInterpolatedPoint(float t)
    {
        Vector3 p0 = GetControlPoint(0);
        Vector3 p1 = GetControlPoint(1);

        float xpos = p0.x * (1 - t) + p1.x * t;
        float ypos = p0.y * (1 - t) + p1.y * t;
        float zpos = p0.z * (1 - t) + p1.z * t;

        return new Vector3(xpos, ypos, zpos); 	
    }
          
}

