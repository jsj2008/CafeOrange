﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode]
public class BSplineCurve : Shape
{
    [System.Serializable]
    public class SplineCurvePoint
    {
        public CurveControlPoints controlPointList = new CurveControlPoints();
        public List<Vector3> vertexList = new List<Vector3>();

    };

    
    #region (Editor Property)
    public int ControlPointCount;
    public int CurveOrder;
    public Dictionary<int, SplineCurvePoint> BSplineCurveOrderList = new Dictionary<int, SplineCurvePoint>();
    #endregion

    private List<float> KVectorList = new List<float>();

    public BSplineCurve()
    {
        AxisAlign = eAxisAlign.AXIS_ALIGN_Z;

        ControlPointCount = 5;
        CurveOrder = 4;

        Reset();
    }

    void Reset()
    {
        KVectorList.Clear();

        MakeKVector();
    }


    void MakeKVector()
    {
        float KValue =0.0f;
        for (int index = 0; index < ControlPointCount + CurveOrder; index++ )
        {
            if (index >= CurveOrder  && index <= ControlPointCount)
                KValue++;

            KVectorList.Add(KValue);
        }


        for (int index = 0; index < KVectorList.Count; index++ )
           Debug.Log("KVector"+index +":"+KVectorList[index]);

        for (int index = 0; index < KVectorList.Count; index++)
        {
            float NormalizedKValue = KVectorList[index] / (ControlPointCount - CurveOrder + 1);
            KVectorList[index] = NormalizedKValue;
        }
    }



}



