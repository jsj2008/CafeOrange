﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode]
public	class FreeCurve : CurveShape
{
    [System.Serializable]
    public class SectionInfo
    {
        public float Duration;

        public SectionInfo()
        {
            Duration = 2.0f;
        }
    };

    public List<SectionInfo> SectionInfoList = new List<SectionInfo>();

    private int CurrentSection = 0;
    //private Vector3 Direction = new Vector3();
    //private Vector3 Angle = new Vector3();

    public FreeCurve()
    {
        SectionSize = 2;
        ShapeType = eCurveShapeType.SHAPE_TYPE_FREE;
        AxisAlign = eAxisAlign.AXIS_ALIGN_Z; // eAxisAlign.AXIS_ALIGN_X;

       // Reset();
    }

    public void Reset()
    {
        CurrentSection = 0;
        CreateCurveGuide(SectionSize);
        CreateCurve();        
    }


    public void ProceedSection()
    {
        CurrentSection++;

        if (CurrentSection == SectionSize )
        {
            CurrentSection = 0;
        }

        //MakeForwardDirection();

        //Debug.Log("ForwardDirection : " + Direction);
        // Debug.Log("ForwardAngle(x,y,z) : " + Angle);
    }
    void MakeSectionInfo()
    {
        if (SectionInfoList.Count > 0)
            SectionInfoList.Clear();

        for (int index = 0; index < SectionSize; index++)
        {
            SectionInfoList.Add(new SectionInfo());
        }
    }

    protected override Vector3 GetInterpolatedPoint(float t)
    {
        Vector3 c0 = GetControlPoint(CurrentSection, 0);
        Vector3 c1 = GetControlPoint(CurrentSection, 1);
        Vector3 c2 = GetControlPoint(CurrentSection, 2);
        Vector3 c3 = GetControlPoint(CurrentSection, 3);

        Vector3 position = new Vector3();
        position.x = (BersteinCurve_B0(t) * c0.x) + (BersteinCurve_B1(t) * c1.x) +
                              (BersteinCurve_B2(t) * c2.x) + (BersteinCurve_B3(t) * c3.x);

        position.y = (BersteinCurve_B0(t) * c0.y) + (BersteinCurve_B1(t) * c1.y) +
                             (BersteinCurve_B2(t) * c2.y) + (BersteinCurve_B3(t) * c3.y);

        position.z = (BersteinCurve_B0(t) * c0.z) + (BersteinCurve_B1(t) * c1.z) +
                             (BersteinCurve_B2(t) * c2.z) + (BersteinCurve_B3(t) * c3.z);

        return position;    
    }

    void Awake()
    {
        Reset();
    }
    void OnDrawGizmosSelected()
    {
        if (FixedTransform)
        {
            transform.position = Vector3.zero;
            return;
        }

        NewBasePosition = transform.position;

        if (NewBasePosition != BasePosition)
        {
            Vector3 Movement = NewBasePosition - BasePosition;
            MoveControlPoints(Movement);
            BasePosition = NewBasePosition;

            CreateCurve();
        }

    }

}

