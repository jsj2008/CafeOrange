﻿using UnityEngine;
using System.Collections;


public class FreeCurveTracker : MonoBehaviour 
{
    public FreeCurve CurveTracker;

     private float deltaTime = 0.0f;
    private bool triggerLookAt = true;

    void FixedUpdate()
    {
        deltaTime += Time.deltaTime / 2.0f;
        if (deltaTime >= 1f)
        {
            deltaTime = 0f;
            CurveTracker.ProceedSection();
        }
        
        if(CurveTracker.FixedTransform)
            transform.position = CurveTracker.GetPoint(deltaTime);
        else
            transform.position = CurveTracker.transform.position + CurveTracker.GetPoint(deltaTime);

    }
}

