﻿using UnityEngine;
using System.Collections;

public class SingleLineTracker : MonoBehaviour 
{
    public SingleLine LineTracker;
    public float Duration = 5.0f;
    
    private float deltaTime = 0.0f;
    
	void FixedUpdate() 
    {
        deltaTime += Time.deltaTime / Duration;

        if (deltaTime > 1f)
        {
            deltaTime = 0f;                      
        }
        
        if(LineTracker.FixedTransform)        
            transform.position = LineTracker.GetPoint(deltaTime);
        else
            transform.position = LineTracker.transform.position + LineTracker.GetPoint(deltaTime);
	}
}
