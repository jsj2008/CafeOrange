﻿using UnityEngine;
using System.Collections;


public class MultiLineTracker : MonoBehaviour 
{
    public MultiLine LineTracker;

    private float deltaTime = 0.0f;
    private bool triggerLookAt = true;
    void FixedUpdate()
    {
        deltaTime += Time.deltaTime / LineTracker.GetDuration();

        if (deltaTime >= 1f)
        {
            LineTracker.ProceedSection();          
            deltaTime = 0f;
            triggerLookAt = true;
        }
        
        transform.position = LineTracker.GetPoint(deltaTime);
        if (triggerLookAt && LineTracker.AutoDirection)
        {            
            transform.eulerAngles = LineTracker.GetDirection();
            triggerLookAt = false;
        }
    }


}

