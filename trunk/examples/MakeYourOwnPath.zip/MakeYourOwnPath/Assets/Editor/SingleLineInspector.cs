﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SingleLine)), CanEditMultipleObjects]
public class LineInspector : Editor
{
    SingleLine line;

    private void OnSceneGUI()
    {
        line = target as SingleLine;
    
        Transform handleTransform = line.transform;
        Quaternion handleRotation = Tools.pivotRotation == PivotRotation.Local ? handleTransform.rotation : Quaternion.identity;

//        Vector3 p0 = handleTransform.TransformPoint(line.GetPoint(0));
//        Vector3 p1 = handleTransform.TransformPoint(line.GetPoint(1));

        Vector3 p0 = handleTransform.TransformPoint(line.GetControlPoint(0));
        Vector3 p1 = handleTransform.TransformPoint(line.GetControlPoint(1));

        Handles.color = Color.white;
        Handles.DrawLine(p0, p1);
        EditorGUI.BeginChangeCheck();
                        
        p0 = Handles.DoPositionHandle(p0, handleRotation);

        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(line, "Move Point");
            EditorUtility.SetDirty(line);
            line.SetPoint(0,handleTransform.InverseTransformPoint(p0));
        }

        EditorGUI.BeginChangeCheck();

        p1 = Handles.DoPositionHandle(p1, handleRotation);

        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(line, "Move Point");
            EditorUtility.SetDirty(line);
            line.SetPoint(1,handleTransform.InverseTransformPoint(p1));
        }
        
    }


}