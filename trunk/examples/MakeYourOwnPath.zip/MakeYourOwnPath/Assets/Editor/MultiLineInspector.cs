﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;


[CustomEditor(typeof(MultiLine)),CanEditMultipleObjects]
public class MultiLineInspector : Editor
{
    
    MultiLine line;

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        SerializedProperty
            ControlPointSize = serializedObject.FindProperty("ControlPointSize");
        serializedObject.Update();

        ControlPointSize.intValue = EditorGUILayout.IntField("ControlPointSize", ControlPointSize.intValue);
        if (line!= null && serializedObject.ApplyModifiedProperties())
        {
            if (ControlPointSize.intValue < 3)
            {
                ControlPointSize.intValue = 3;
                return;
            }
            line.Reset();
        }
    }

    private void OnSceneGUI()
    {
        line = target as MultiLine;

        Transform handleTransform = line.transform;
        Quaternion handleRotation = Tools.pivotRotation == PivotRotation.Local ? handleTransform.rotation : Quaternion.identity;

        int NumberOfControlPoints = line.ControlPointList.Count;
        Vector3[] ControlPointList = new Vector3[NumberOfControlPoints];
        for (int index = 0; index < NumberOfControlPoints; index++)
        {
            ControlPointList[index] = handleTransform.TransformPoint(line.GetControlPoint(index));
        }

        Handles.color = Color.yellow;
        Handles.DrawPolyLine(ControlPointList);
        for (int index = 0; index < NumberOfControlPoints; index++)
        {
            EditorGUI.BeginChangeCheck();
            Vector3 position = Handles.DoPositionHandle(ControlPointList[index], handleRotation);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(line, "Move Point");
                EditorUtility.SetDirty(line);
                line.SetPoint(index, handleTransform.InverseTransformPoint(position));
            }
        }

   


        //Event _event = Event.current;
        //switch (_event.type)
        //{
        //case EventType.KeyDown:
        //    {
        //        if (Event.current.keyCode == (KeyCode.Delete))
        //        {
        //            Debug.Log(GUIUtility.hotControl);
        //            //Debug.Log("Index : " + controlInfo.Key + " ID: " + controlInfo.Value);
        //        }
        //    }
        //    break;
        //}


    }

    //public override void OnInspectorGUI()
    //{
        //base.OnInspectorGUI();

        //if (GUILayout.Button("Insert Control Point"))
        //{

        //}
        //else if (GUILayout.Button("Delete Control Point"))
        //{
        //    foreach (KeyValuePair<int, int> controlInfo in ControlIDMap)
        //    {
        //        if (controlInfo.Key == GUIUtility.hotControl)
        //        {
        //            Debug.Log("Index : " + controlInfo.Key +" ID: " + controlInfo.Value);
        //            return;
        //        }
        //    }
        //}
    //}
}
