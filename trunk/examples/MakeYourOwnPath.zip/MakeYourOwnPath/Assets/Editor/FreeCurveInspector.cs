﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

[CustomEditor(typeof(FreeCurve)), CanEditMultipleObjects]
public class FreeCurveInspector : Editor
{
    FreeCurve curve;

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        if (GUILayout.Button("Update"))
        {
            curve.Reset();
            EditorUtility.SetDirty(curve);
        }
    }

    private void OnSceneGUI()
    {
        curve = target as FreeCurve;

        Transform handleTransform = curve.transform;
        Quaternion handleRotation = Tools.pivotRotation == PivotRotation.Local ? handleTransform.rotation : Quaternion.identity;

        if (curve.curveControlPoints.ControlPointList.Count == 0 ||
            curve.curveControlPoints.SectionSize != curve.SectionSize)
            return;

        int NumberOfSection = curve.SectionSize;
        int NumberOfCountPoints = NumberOfSection > 1 ? NumberOfSection * 4 - (curve.SectionSize - 1) : NumberOfSection;
        Vector3[] ControlPointList = new Vector3[NumberOfCountPoints];
        for (int index = 0; index < NumberOfCountPoints; index++)
        {
           ControlPointList[index] = handleTransform.TransformPoint(curve.GetControlPoint(index));
        }

        Handles.color = Color.green;
        Handles.DrawPolyLine(ControlPointList);

        for (int index = 0; index < NumberOfCountPoints; index++)
        {
            EditorGUI.BeginChangeCheck();
            Vector3 position = Handles.DoPositionHandle(ControlPointList[index], handleRotation);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(curve, "Move Point");
                EditorUtility.SetDirty(curve);
                curve.SetPoint(index, handleTransform.InverseTransformPoint(position));                
            }
        }

        Handles.color = Color.red;
        List<FreeCurve.ControlPoint> CurvePointList = curve.GetCurvePoint();
        for (int index = 0; index < CurvePointList.Count - 1; index++ )
        {
            Vector3 p0 = handleTransform.TransformPoint(CurvePointList[index].position);
            Vector3 p1 = handleTransform.TransformPoint(CurvePointList[index+1].position);
            Handles.DrawLine(p0, p1);
        }
    }


}
