﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

[CustomEditor(typeof(FreeCurve)), CanEditMultipleObjects]
public class BSplineCurveInspector : Editor
{

}

